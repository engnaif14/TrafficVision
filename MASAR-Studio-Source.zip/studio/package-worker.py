"""Package MASAR pages with same-origin forecasting requests."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
pages = {
    "/": ["text/html; charset=utf-8", (root / "dist/index.html").read_text()],
    "/lab": ["text/html; charset=utf-8", (root / "studio/lab.html").read_text()],
    "/masar-mark.svg": ["image/svg+xml", (root / "studio/masar-mark.svg").read_text()],
}
source = "const pages = " + json.dumps(pages, ensure_ascii=False) + ";\n"
source += """
const apiPaths = new Set(['/api/analyze', '/api/analyze/inspect', '/api/analyze/example']);
export default {
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/lab/' || url.pathname === '/lab.html') {
      return Response.redirect(url.origin + '/lab', 302);
    }
    if (apiPaths.has(url.pathname)) {
      if (request.method !== 'POST') return new Response('Method not allowed', {status:405});
      const length = request.headers.get('content-length');
      if (!length || Number(length) > 3000000) {
        return Response.json({error:'حجم الملف غير مقبول'}, {status:413});
      }
      try {
        const upstream = await fetch('https://trafficvision-jazan.onrender.com' + url.pathname, {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:await request.arrayBuffer(),
          redirect:'manual'
        });
        if (upstream.status >= 300 && upstream.status < 400) {
          return Response.json({error:'خدمة التحليل غير متاحة مؤقتًا'}, {status:503});
        }
        return new Response(upstream.body, {
          status:upstream.status,
          headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}
        });
      } catch (error) {
        console.error('Forecast service request failed', error.message);
        return Response.json({error:'تعذر الوصول لخدمة التحليل. أعد المحاولة بعد قليل.'}, {status:503});
      }
    }
    const page = pages[url.pathname];
    if (!page) return new Response('Not found', {status:404});
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed', {status:405});
    return new Response(request.method === 'HEAD' ? null : page[1], {
      headers:{'Content-Type':page[0],'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'}
    });
  }
};
"""
out = root / "dist/server/index.js"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(source)
