"""Render an OSM XML extract into a compact, offline Jazan map for MASAR."""
import json
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

from shapely.geometry import LineString, Polygon, box
from shapely.ops import linemerge

WEST, SOUTH, EAST, NORTH = 42.527, 16.869, 42.593, 16.925
WIDTH, HEIGHT = 640, 569
BOUNDS = box(WEST, SOUTH, EAST, NORTH)
root = ET.parse(sys.argv[1]).getroot()
nodes = {n.attrib["id"]: (float(n.attrib["lon"]), float(n.attrib["lat"])) for n in root.findall("node")}
ways = {}
for way in root.findall("way"):
    points = [nodes[n.attrib["ref"]] for n in way.findall("nd")]
    if len(points) > 1:
        ways[way.attrib["id"]] = (points, {t.attrib["k"]: t.attrib["v"] for t in way.findall("tag")})


def point(x, y):
    return [round((x - WEST) / (EAST - WEST) * WIDTH, 1), round((NORTH - y) / (NORTH - SOUTH) * HEIGHT, 1)]


def path(geometry):
    if geometry.is_empty:
        return ""
    if hasattr(geometry, "geoms"):
        return "".join(path(part) for part in geometry.geoms)
    if geometry.geom_type == "Polygon":
        return path(geometry.exterior) + "Z" + "".join(path(ring) + "Z" for ring in geometry.interiors)
    if geometry.geom_type not in ("LineString", "LinearRing"):
        return ""
    return "M" + " ".join(",".join(map(str, point(x, y))) for x, y in geometry.coords)


coast = linemerge([LineString(p) for p, tags in ways.values() if tags.get("natural") == "coastline"])
coast_coords = list(coast.coords)
if coast_coords[0][1] < coast_coords[-1][1]:
    coast_coords.reverse()
land = Polygon(coast_coords + [(43, coast_coords[-1][1]), (43, coast_coords[0][1])]).buffer(0)
layers = {key: [] for key in ("minor", "major", "green", "airport")}
for points, tags in ways.values():
    highway = tags.get("highway")
    layer = None
    if highway in {"trunk", "primary", "secondary", "tertiary", "trunk_link", "primary_link"}:
        layer = "major"
    elif highway in {"residential", "living_street", "unclassified", "service", "secondary_link"}:
        layer = "minor"
    elif points[0] == points[-1] and len(points) >= 4:
        if tags.get("leisure") == "park" or tags.get("landuse") in {"grass", "recreation_ground"}:
            layer = "green"
        elif tags.get("aeroway") in {"apron", "aerodrome"}:
            layer = "airport"
        if layer:
            shape = Polygon(points).buffer(0)
    elif tags.get("aeroway") == "runway":
        layer = "major"
    if layer:
        if layer in {"minor", "major"}:
            shape = LineString(points)
        clipped = shape.intersection(BOUNDS).simplify(0.000045)
        layers[layer].append(path(clipped))

groups = [
    (["94439042"], BOUNDS), (["1465036891", "1112585605", "94457915"], box(WEST, SOUTH, EAST, 16.903)),
    (["94433787"], box(WEST, SOUTH, 42.570, NORTH)), (["94433787"], box(42.570, SOUTH, EAST, NORTH)),
    (["94447106"], BOUNDS), (["94513897"], BOUNDS),
]
segments = ["".join(path(LineString(ways[id][0]).intersection(area)) for id in ids) for ids, area in groups]
assert all(segments)
data = {"size": [WIDTH, HEIGHT], "land": path(land.intersection(BOUNDS).simplify(0.000035)),
        **{layer: "".join(parts) for layer, parts in layers.items()}, "segments": segments,
        "labels": [
            [*point(42.532, 16.906), "البحر الأحمر", "Red Sea"],
            [*point(42.55365, 16.91945), "الشاطئ", "Ash Shati"],
            [*point(42.5680, 16.9151), "الروضة", "Ar Rawdah"],
            [*point(42.5744, 16.9030), "مطار جازان", "Jazan Airport"],
            [*point(42.5593, 16.8870), "جيزان", "Jazan"],
            [*point(42.5510, 16.8796), "الجبل", "Al Jabal"],
        ]}
Path(sys.argv[2]).write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n")
