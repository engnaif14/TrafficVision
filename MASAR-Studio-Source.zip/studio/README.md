# MASAR Studio

Independent review build for the Jazan simulation. The production application and forecast lab are untouched. The preview links to the existing lab.

From the repository root, install `requirements.txt` in your virtual environment, then run:

```sh
python studio/build.py /path/to/MASAR-Studio.html
```

Open the generated file in a browser. It contains all assets and the hourly model projection. Rebuild to refresh the forecast anchor. An online browser can overlay up to 48 matching forecast hours from Open-Meteo. The rest use labeled illustrative weather.

Scenarios adjust the existing weather-aware model's weather regressors and the selected segment's assumed capacity. The three routes, traffic history, segment geometry and capacity form a research simulation. The app reports projected arrivals and weather/closure exposure, without modeling diversion, collision probability, or incident detection.

The embedded map uses geographic road and coastline data © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright) under the ODbL. Traffic and capacity overlays remain simulated. The map renders offline from `jazan-map.json`.

To refresh geometry, use the [OSM XML extract](https://www.openstreetmap.org/api/0.6/map?bbox=42.522,16.861,42.600,16.936) with `python studio/map_data.py input.osm studio/jazan-map.json` (requires Shapely for this optional step).

For a hosted version, run the following with your assigned HTTPS homepage URL, then serve both files at the site root:

```sh
mkdir -p public
python studio/build.py public/index.html --site-url https://your-site.example/
```

This generates `index.html` and `masar-mark.svg` with a stable favicon URL and homepage site-name metadata. The traffic forecast is embedded at build time, so a continuously refreshed public deployment needs a scheduled build.

The primary homepage and lab are served by the Site Worker. Build the homepage with build.py, then run python studio/package-worker.py. The lab uses same-origin POST endpoints backed by the existing Render analysis service.

The production deployment uses app.py on Render. Both the homepage and the laboratory use the same origin.
